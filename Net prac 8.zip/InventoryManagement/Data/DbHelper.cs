using Microsoft.Data.SqlClient;

namespace InventoryManagement.Data;

/// <summary>Holds the connection string and prepares the database/table (ADO.NET).</summary>
public static class DbHelper
{
    // Change this to match your SQL Server instance.
    private const string Server = @"(localdb)\MSSQLLocalDB";
    private const string DbName = "InventoryDB";

    public static string ConnectionString =>
        $"Server={Server};Database={DbName};Trusted_Connection=True;TrustServerCertificate=True;";

    private static string MasterConnectionString =>
        $"Server={Server};Database=master;Trusted_Connection=True;TrustServerCertificate=True;";

    /// <summary>Creates the database and Products table if they do not exist.</summary>
    public static void Initialize()
    {
        using (var master = new SqlConnection(MasterConnectionString))
        {
            master.Open();
            string createDb = $"IF DB_ID('{DbName}') IS NULL CREATE DATABASE [{DbName}];";
            using var cmd = new SqlCommand(createDb, master);
            cmd.ExecuteNonQuery();
        }

        const string createTable = @"
            IF OBJECT_ID('dbo.Products','U') IS NULL
            CREATE TABLE dbo.Products (
                ProductId INT IDENTITY(1,1) PRIMARY KEY,
                Name      NVARCHAR(100) NOT NULL,
                Category  NVARCHAR(50)  NOT NULL,
                Quantity  INT           NOT NULL CHECK (Quantity >= 0),
                Price     DECIMAL(10,2) NOT NULL CHECK (Price >= 0),
                CreatedOn DATETIME      NOT NULL DEFAULT GETDATE()
            );";

        using var con = new SqlConnection(ConnectionString);
        con.Open();
        using var tbl = new SqlCommand(createTable, con);
        tbl.ExecuteNonQuery();
    }
}
