using InventoryManagement.Models;
using Microsoft.Data.SqlClient;

namespace InventoryManagement.Data;

/// <summary>CRUD operations on Products using ADO.NET (SqlConnection, SqlCommand, SqlDataReader).</summary>
public class ProductRepository
{
    private const string SelectCols = "SELECT ProductId, Name, Category, Quantity, Price, CreatedOn FROM Products ";

    // ---------- CREATE ----------
    public int Add(Product p)
    {
        const string sql = @"INSERT INTO Products (Name, Category, Quantity, Price)
                             VALUES (@Name, @Category, @Quantity, @Price);
                             SELECT CAST(SCOPE_IDENTITY() AS INT);";
        using var con = new SqlConnection(DbHelper.ConnectionString);
        using var cmd = new SqlCommand(sql, con);
        cmd.Parameters.AddWithValue("@Name", p.Name);
        cmd.Parameters.AddWithValue("@Category", p.Category);
        cmd.Parameters.AddWithValue("@Quantity", p.Quantity);
        cmd.Parameters.AddWithValue("@Price", p.Price);
        con.Open();
        return (int)cmd.ExecuteScalar()!;   // returns new ProductId
    }

    // ---------- READ (all) ----------
    public List<Product> GetAll()
    {
        var list = new List<Product>();
        using var con = new SqlConnection(DbHelper.ConnectionString);
        using var cmd = new SqlCommand(SelectCols + "ORDER BY ProductId", con);
        con.Open();
        using var rd = cmd.ExecuteReader();
        while (rd.Read()) list.Add(Map(rd));
        return list;
    }

    // ---------- READ (one) ----------
    public Product? GetById(int id)
    {
        using var con = new SqlConnection(DbHelper.ConnectionString);
        using var cmd = new SqlCommand(SelectCols + "WHERE ProductId=@Id", con);
        cmd.Parameters.AddWithValue("@Id", id);
        con.Open();
        using var rd = cmd.ExecuteReader();
        return rd.Read() ? Map(rd) : null;
    }

    // ---------- SEARCH ----------
    public List<Product> Search(string keyword)
    {
        var list = new List<Product>();
        using var con = new SqlConnection(DbHelper.ConnectionString);
        using var cmd = new SqlCommand(SelectCols + "WHERE Name LIKE @K OR Category LIKE @K ORDER BY ProductId", con);
        cmd.Parameters.AddWithValue("@K", $"%{keyword}%");
        con.Open();
        using var rd = cmd.ExecuteReader();
        while (rd.Read()) list.Add(Map(rd));
        return list;
    }

    // ---------- LOW STOCK REPORT ----------
    public List<Product> GetLowStock(int threshold)
    {
        var list = new List<Product>();
        using var con = new SqlConnection(DbHelper.ConnectionString);
        using var cmd = new SqlCommand(SelectCols + "WHERE Quantity <= @T ORDER BY Quantity", con);
        cmd.Parameters.AddWithValue("@T", threshold);
        con.Open();
        using var rd = cmd.ExecuteReader();
        while (rd.Read()) list.Add(Map(rd));
        return list;
    }

    // ---------- UPDATE ----------
    public bool Update(Product p)
    {
        const string sql = @"UPDATE Products
                             SET Name=@Name, Category=@Category, Quantity=@Quantity, Price=@Price
                             WHERE ProductId=@Id";
        using var con = new SqlConnection(DbHelper.ConnectionString);
        using var cmd = new SqlCommand(sql, con);
        cmd.Parameters.AddWithValue("@Id", p.ProductId);
        cmd.Parameters.AddWithValue("@Name", p.Name);
        cmd.Parameters.AddWithValue("@Category", p.Category);
        cmd.Parameters.AddWithValue("@Quantity", p.Quantity);
        cmd.Parameters.AddWithValue("@Price", p.Price);
        con.Open();
        return cmd.ExecuteNonQuery() > 0;
    }

    // ---------- DELETE ----------
    public bool Delete(int id)
    {
        using var con = new SqlConnection(DbHelper.ConnectionString);
        using var cmd = new SqlCommand("DELETE FROM Products WHERE ProductId=@Id", con);
        cmd.Parameters.AddWithValue("@Id", id);
        con.Open();
        return cmd.ExecuteNonQuery() > 0;
    }

    // Maps the current reader row to a Product object.
    private static Product Map(SqlDataReader rd) => new()
    {
        ProductId = rd.GetInt32(0),
        Name      = rd.GetString(1),
        Category  = rd.GetString(2),
        Quantity  = rd.GetInt32(3),
        Price     = rd.GetDecimal(4),
        CreatedOn = rd.GetDateTime(5)
    };
}
