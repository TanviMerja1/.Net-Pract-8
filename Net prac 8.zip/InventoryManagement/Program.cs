using InventoryManagement.Data;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Create database + table on first run (ADO.NET)
DbHelper.Initialize();

app.UseStaticFiles();
app.UseRouting();

// Default page = Products list
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Products}/{action=Index}/{id?}");

app.Run();
