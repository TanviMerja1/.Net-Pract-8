-- Optional: the app creates this automatically on first run.
IF DB_ID('InventoryDB') IS NULL CREATE DATABASE InventoryDB;
GO
USE InventoryDB;
GO
IF OBJECT_ID('dbo.Products','U') IS NULL
CREATE TABLE dbo.Products (
    ProductId INT IDENTITY(1,1) PRIMARY KEY,
    Name      NVARCHAR(100) NOT NULL,
    Category  NVARCHAR(50)  NOT NULL,
    Quantity  INT           NOT NULL CHECK (Quantity >= 0),
    Price     DECIMAL(10,2) NOT NULL CHECK (Price >= 0),
    CreatedOn DATETIME      NOT NULL DEFAULT GETDATE()
);
GO
INSERT INTO Products (Name, Category, Quantity, Price) VALUES
('Wireless Mouse','Electronics',50,599.00),
('USB Keyboard','Electronics',8,799.00),
('A4 Paper Ream','Stationery',120,325.50);
