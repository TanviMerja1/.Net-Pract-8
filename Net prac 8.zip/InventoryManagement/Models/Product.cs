using System.ComponentModel.DataAnnotations;

namespace InventoryManagement.Models;

/// <summary>Represents one row of the Products table.</summary>
public class Product
{
    public int ProductId { get; set; }

    [Required, StringLength(100)]
    public string Name { get; set; } = string.Empty;

    [Required, StringLength(50)]
    public string Category { get; set; } = string.Empty;

    [Range(0, int.MaxValue, ErrorMessage = "Quantity cannot be negative")]
    public int Quantity { get; set; }

    [Range(0, 9999999, ErrorMessage = "Price cannot be negative")]
    public decimal Price { get; set; }

    [Display(Name = "Created On")]
    public DateTime CreatedOn { get; set; }
}
