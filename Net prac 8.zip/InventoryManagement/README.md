# Experiment 8 – Inventory Management Module (ADO.NET + CRUD)

ASP.NET Core MVC web app (.NET 8) that runs in Chrome. Data access uses plain ADO.NET
(`SqlConnection`, `SqlCommand`, `SqlDataReader`) with SQL Server LocalDB.

## Run (opens in Chrome)
**Visual Studio:** open the folder / .csproj, press F5 (set Chrome as browser via the Run dropdown -> Browse With).
**Command line:** `dotnet run`, then open http://localhost:5000 in Chrome.

The database `InventoryDB` and table `Products` are created automatically.
If you use full SQL Server instead of LocalDB, edit `Server` in `Data/DbHelper.cs`.

## Features
Add, list, view, edit, delete, search, low-stock report.

## Push to GitHub
```
git init
git add .
git commit -m "Ex-8 Inventory Management ADO.NET CRUD"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```
