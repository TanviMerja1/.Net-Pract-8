using InventoryManagement.Data;
using InventoryManagement.Models;
using Microsoft.AspNetCore.Mvc;

namespace InventoryManagement.Controllers;

/// <summary>Handles all CRUD pages. Data access is done via ADO.NET in ProductRepository.</summary>
public class ProductsController : Controller
{
    private readonly ProductRepository _repo = new();

    // READ: list + search
    public IActionResult Index(string? search)
    {
        ViewData["Search"] = search;
        var items = string.IsNullOrWhiteSpace(search) ? _repo.GetAll() : _repo.Search(search);
        return View(items);
    }

    // READ: low stock report
    public IActionResult LowStock(int threshold = 10)
    {
        ViewData["Threshold"] = threshold;
        return View(_repo.GetLowStock(threshold));
    }

    // READ: one product
    public IActionResult Details(int id)
    {
        var p = _repo.GetById(id);
        return p == null ? NotFound() : View(p);
    }

    // CREATE
    public IActionResult Create() => View(new Product());

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Create(Product p)
    {
        if (!ModelState.IsValid) return View(p);
        _repo.Add(p);
        TempData["Msg"] = "Product added successfully.";
        return RedirectToAction(nameof(Index));
    }

    // UPDATE
    public IActionResult Edit(int id)
    {
        var p = _repo.GetById(id);
        return p == null ? NotFound() : View(p);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Edit(int id, Product p)
    {
        p.ProductId = id;
        if (!ModelState.IsValid) return View(p);
        _repo.Update(p);
        TempData["Msg"] = "Product updated successfully.";
        return RedirectToAction(nameof(Index));
    }

    // DELETE
    public IActionResult Delete(int id)
    {
        var p = _repo.GetById(id);
        return p == null ? NotFound() : View(p);
    }

    [HttpPost, ActionName("Delete"), ValidateAntiForgeryToken]
    public IActionResult DeleteConfirmed(int id)
    {
        _repo.Delete(id);
        TempData["Msg"] = "Product deleted successfully.";
        return RedirectToAction(nameof(Index));
    }
}
